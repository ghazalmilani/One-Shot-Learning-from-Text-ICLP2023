related_to(air,environment).
related_to(water,environment).
%related_to(earth,environment).
related_to(nature,environment).
related_to(climate,environment).
related_to(ecology,environment).
related_to(habitat,environment).
related_to(forest,environment).
related_to(ocean,environment).
related_to(wildlife,environment).
%related_to(species,environment).
%related_to(conservation,environment).
related_to(pollution,environment).
related_to(sustainability,environment).
related_to(ecosystem,environment).

related_to(biodiversity,environment).
related_to(climate_change,environment).
related_to(recycling,environment).

% related_to(land,environment).
% related_to(flora,environment).
%related_to(fauna,environment).
related_to(wetland,environment).
related_to(desert,environment).
%related_to(mountain,environment).
%related_to(river,environment).
% related_to(lake,environment).
% related_to(pond,environment).
% related_to(soil,environment).
%related_to(valley,environment).
related_to(glacier,environment).
related_to(coral,environment).
related_to(rainforest,environment).
%related_to(savannah,environment).
%related_to(grassland,environment).
%related_to(marsh,environment).
%related_to(estuary,environment).
%related_to(delta,environment).
% related_to(dune,environment).
% related_to(cavern,environment).
% related_to(biosphere,environment).
%related_to(biome,environment).
% related_to(tide,environment).
% related_to(wind,environment).
% related_to(rain,environment).
% related_to(sun,environment).
% related_to(carbon,environment).
% related_to(oxygen,environment).
%related_to(nitrogen,environment).
related_to(photosynthesis,environment).
%related_to(respiration,environment).
related_to(decomposition,environment).
%related_to(fertilizer,environment).
%related_to(pesticide,environment).
%related_to(herbicide,environment).
related_to(insecticide,environment).
related_to(deforestation,environment).
related_to(afforestation,environment).
related_to(reforestation,environment).
related_to(landfill,environment).
%related_to(waste,environment).
related_to(compost,environment).
related_to(renewable_energy,environment).
related_to(solar,environment).
related_to(wind_power,environment).
%related_to(hydroelectric,environment).
related_to(geothermal,environment).
related_to(tidal,environment).
%related_to(biomass,environment).
related_to(greenhouse,environment).
related_to(global_warming,environment).
related_to(greenhouse_gases,environment).
related_to(carbon_dioxide,environment).
%related_to(methane,environment).
related_to(ozone,environment).
related_to(smog,environment).
related_to(acid_rain,environment).
%related_to(erosion,environment).
related_to(desertification,environment).
%related_to(drought,environment).
related_to(flood,environment).
related_to(cyclone,environment).
related_to(hurricane,environment).
related_to(tornado,environment).
related_to(tsunami,environment).
related_to(avalanche,environment).
%related_to(hail,environment).
%related_to(sleet,environment).
%related_to(blizzard,environment).
related_to(ecological,environment).
%related_to(organic,environment).
related_to(sustainable,environment).
%related_to(pollutant,environment).
%%%%%%%%%%%%%%%%%%%%%
related_to(environmentalism,environment).
related_to(environmental,environment).
related_to(nature,environment).
related_to(sustainability,environment).
related_to(ecosystem,environment).
related_to(pollution,environment).
related_to(recycling,environment).
related_to(biodiversity,environment).
related_to(climate,environment).
related_to(greenhouse_gases,environment).
related_to(deforestation,environment).
related_to(ozone_layer,environment).
related_to(renewable_energy,environment).
related_to(carbon_footprint,environment).
related_to(global_warming,environment).
%related_to(nature,environment).
related_to(natural_resources,environment).

%related_to(emission,environment).
related_to(biodegradable,environment).
related_to(wildlife,environment).
related_to(ecological,environment).
related_to(air_quality,environment).
related_to(water_conservation,environment).
%related_to(organic,environment).
related_to(composting,environment).
related_to(green_living,environment).
related_to(waste_management,environment).
related_to(agriculture,environment).

related_to(solar,environment).

related_to(sustainable_agriculture,environment).
related_to(solar_power,environment).
related_to(energy_efficiency,environment).
related_to(carbon_dioxide,environment).
%related_to(rain,environment).
related_to(acid_rain,environment).
related_to(landfills,environment).
%related_to(biology,environment).
related_to(sustainable,environment).
%related_to(ocean,environment).
%related_to(sea,environment).
related_to(rainforest,environment).

related_to(environmentalist,environment).
related_to(ecology,environment).
related_to(environmentalism,environment).
related_to(macroenvironment,environment).
%related_to(weather,environment).
related_to(animal,environment).
related_to(plant,environment).