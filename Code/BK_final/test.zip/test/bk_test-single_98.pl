%contains(example_98,second).
% related_to(second,first).
% related_to(second,minute).
% related_to(second,seconds).
% related_to(second,omer).
% related_to(second,silver).
% related_to(second,moment).
% related_to(second,base).
% related_to(second,time).
% related_to(second,retry).
% related_to(second,combat).
% related_to(second,precede).
% related_to(second,octave).
% related_to(second,secundal).
% related_to(second,secondary).
% related_to(second,secundogeniture).
% related_to(second,aftergame).
% related_to(second,katal).
% related_to(second,two).
% related_to(second,remarry).
% related_to(second,cumec).
% related_to(second,kilocycle).
% related_to(second,two_l).
% related_to(second,occurrence).
% related_to(second,seconded).
% related_to(second,dwitiya).
% related_to(second,transfer_rate).
% related_to(second,third).
% related_to(second,all_souls_day).
% related_to(second,blue_moon).
% related_to(second,rutherford).
% related_to(second,second_gear).
% related_to(second,seckill).
% related_to(second,sixtieth).
% related_to(second,kilohertz).
% related_to(second,perfect_pitch).
% related_to(second,ultrapasteurization).
% related_to(second,macroacquisition).
% related_to(second,secondness).
% related_to(second,maxwell).
% related_to(second,assist).
% related_to(second,kine).
% related_to(second,petaflop).
% related_to(second,b_team).
% related_to(second,duel).
% related_to(second,napoleon).
% related_to(second,agree).
% related_to(second,joule).
% related_to(second,just_second).
% related_to(second,accent).
% related_to(second,digamous).
% related_to(second,standard_gravity).
% related_to(second,mbps).
% related_to(second,centimeter_gram_second).
% related_to(second,joule_second).
% related_to(second,greek_foot).
% related_to(second,gigasecond).
% related_to(second,watt).
% related_to(second,quefrency).
% related_to(second,envoy).
% related_to(second,sixty_second).
% related_to(second,deutero).
% related_to(second,climb).
% related_to(second,forty_second).
% related_to(second,secondment).
% related_to(second,diatonic).
% related_to(second,secundipara).
% related_to(second,pulsatance).
% related_to(second,megasecond).
% related_to(second,deuterotheme).
% related_to(second,accent_mark).
% related_to(second,meter).
% related_to(second,prime).
% related_to(second,inverse).
% related_to(second,absolute_zero).
% related_to(second,rayleigh).
% related_to(second,kiloflops).
% related_to(second,seventy_second).
% related_to(second,both).
% related_to(second,holiday_home).
% related_to(second,microcentury).
% related_to(second,one_and_one).
% related_to(second,mts).
% related_to(second,indeterminate).
% related_to(second,wu).
% related_to(second,accidental).
% related_to(second,electric_current).
% related_to(second,contest).
% related_to(second,other).
% related_to(second,after).
% related_to(second,atom).
% related_to(second,biordinal).
% related_to(second,megaflop).
% related_to(second,newton).
% related_to(second,runner_up).
% related_to(second,yottasecond).
% related_to(second,foot_pound_second).
% related_to(second,sophomore).
% related_to(second,speed_of_light).
% related_to(second,sixer).
% related_to(second,cub_scout).
% related_to(second,quorum).
% related_to(second,hectosecond).
% related_to(second,zeptosecond).
% related_to(second,subordinate).
% related_to(second,thirty_second).
% related_to(second,millisecond).
% related_to(second,metric_system).
% related_to(second,coulomb).
% related_to(second,succeed).
% related_to(second,aftercrop).
% related_to(second,another).
% related_to(second,hilary_term).
% related_to(second,passing_tone).
% related_to(second,exaflop).
% related_to(second,twenty_second).
% related_to(second,high_priestess).
% related_to(second,double_count).
% related_to(second,kilosecond).
% related_to(second,intersecond).
% related_to(second,bohairic).
% related_to(second,zettasecond).
% related_to(second,abet).
% related_to(second,derived_unit).
% related_to(second,neighbor_tone).
% related_to(second,rank).
% related_to(second,duply).
% related_to(second,data_transfer_rate).
% related_to(second,quality_control).
% related_to(second,back).
% related_to(second,squared).
% related_to(second,ses).
% related_to(second,degree).
% related_to(second,secondmost).
% related_to(second,leap_second).
% related_to(second,lead).
% related_to(second,subsecond).
% related_to(second,precedence).
% related_to(second,secondable).
% related_to(second,bissextile).
% related_to(second,hertz).
% related_to(second,hypercritical_point).
% related_to(second,secondee).
% related_to(second,neutron_flux).
% related_to(second,femtosecond).
% related_to(second,fifty_second).
% related_to(second,david).
% related_to(second,becquerel).
% related_to(second,terasecond).
% related_to(second,si).
% related_to(second,refruiting).
% related_to(second,zettaflop).
% related_to(second,support).
% related_to(second,gbps).
% related_to(second,hearse).
% related_to(second,light_second).
% related_to(second,secondly).
% related_to(second,latter).
% related_to(second,second_degree).
% related_to(second,centiday).
% related_to(second,hamhung).
% related_to(second,just_minute).
% related_to(second,escape_tone).
% related_to(second,second_hand).
% related_to(second,first_loser).
% related_to(second,microsleep).
% related_to(second,seconder).
% related_to(second,unseconded).
% related_to(second,series).
% related_to(second,second_down).
% related_to(second,henry).
% related_to(second,poncelet).
% related_to(second,centisecond).
% related_to(second,earthly_branch).
% related_to(second,twoth).
% related_to(second,flop).
% related_to(second,teraflop).
% related_to(second,secondborn).
% related_to(second,mint_par).
% related_to(second,time_exposure).
% related_to(second,poundal).
% related_to(second,kiloflop).
% related_to(second,exasecond).
% related_to(second,reiterate).
% related_to(second,galileo).
% related_to(second,second_guess).
% related_to(second,frosh).
% related_to(second,second_generation).
% related_to(second,quality).
% related_to(second,jiffy).
% related_to(second,quadfecta).
% related_to(second,mil).
% related_to(second,caesium).
% related_to(second,angle).
% related_to(second,second_order).
% related_to(second,ordinal).
% related_to(second,motion).
% related_to(second,weber).
% related_to(second,second_base).
% related_to(second,radiation).
% related_to(second,inferior).
% related_to(second,multisecond).
% related_to(second,cusec).
% related_to(second,manufactured).
% related_to(second,sequel).
% related_to(second,after_first).
% related_to(second,hour).
% related_to(second,junior).
% related_to(second,street).
% related_to(second,copy).
% related_to(second,vice).
% related_to(second,fourth).
% related_to(second,burn).
% related_to(second,class).
% related_to(second,coat).
% related_to(second,verse).
% related_to(second,forth).
% related_to(second,school).
% related_to(second,have).
% related_to(second,minute_have).
% related_to(second,be).
% related_to(second,he).
% related_to(second,case).
contains(example_98,police-involved).
contains(example_98,shooting).
related_to(shooting,gun).
related_to(shooting,bullet).
related_to(shooting,range).
related_to(shooting,benchrest).
related_to(shooting,modern_pentathlon).
related_to(shooting,crisis_actor).
related_to(shooting,gunfight).
related_to(shooting,game).
related_to(shooting,fire_away).
related_to(shooting,shooting_box).
related_to(shooting,rapid_fire_pistol).
related_to(shooting,district).
related_to(shooting,firearm).
related_to(shooting,bird_dog).
related_to(shooting,shoot).
related_to(shooting,wingshooting).
related_to(shooting,officer_involved).
related_to(shooting,glorious_twelfth).
related_to(shooting,biathlon).
related_to(shooting,nonshooting).
related_to(shooting,tschinke).
related_to(shooting,mass_shooting).
related_to(shooting,pig_war).
related_to(shooting,shooting_match).
related_to(shooting,instinct_shooting).
related_to(shooting,sport).
related_to(shooting,drive_by).
related_to(shooting,double_tap).
related_to(shooting,field_sport).
related_to(shooting,covert_coat).
related_to(shooting,shooting_brake).
related_to(shooting,field_sports).
related_to(shooting,shootings).
related_to(shooting,prone).
related_to(shooting,plinking).
related_to(shooting,codocyte).
related_to(shooting,paper_hunting).
related_to(shooting,fire).
related_to(shooting,copicide).
related_to(shooting,steadicam).
related_to(shooting,rifle).
related_to(shooting,bow).
related_to(shooting,arrow).
related_to(shooting,duel).
related_to(shooting,fountain).
related_to(shooting,cannon).
related_to(shooting,revolver).
related_to(shooting,guard).
contains(example_98,reported).
related_to(reported,data_processing).
related_to(reported,underreported).
related_to(reported,news).
contains(example_98,missouri).
related_to(missouri,festus).
related_to(missouri,california).
related_to(missouri,bloomfield).
related_to(missouri,allendale).
related_to(missouri,ava).
related_to(missouri,lebanon).
related_to(missouri,williamsburg).
related_to(missouri,noel).
related_to(missouri,parker).
related_to(missouri,lodge).
related_to(missouri,worthington).
related_to(missouri,katy).
related_to(missouri,story).
related_to(missouri,rolla).
related_to(missouri,columbia).
related_to(missouri,nodaway_county).
related_to(missouri,hurley).
related_to(missouri,maysville).
related_to(missouri,russellville).
related_to(missouri,springfield).
related_to(missouri,grundy_county).
related_to(missouri,hinton).
related_to(missouri,sibley).
related_to(missouri,knox_county).
related_to(missouri,farkleberry).
related_to(missouri,daviess_county).
related_to(missouri,york).
related_to(missouri,edina).
related_to(missouri,shannon_county).
related_to(missouri,franklin_county).
related_to(missouri,gasconade_county).
related_to(missouri,holt_county).
related_to(missouri,huntsville).
related_to(missouri,smithfield).
related_to(missouri,brookline).
related_to(missouri,adrian).
related_to(missouri,st_charles_county).
related_to(missouri,salisbury).
related_to(missouri,greensburg).
related_to(missouri,westphalia).
related_to(missouri,elmira).
related_to(missouri,kidder).
related_to(missouri,cameron).
related_to(missouri,bolivar).
related_to(missouri,kearney).
related_to(missouri,fillmore).
related_to(missouri,kelso).
related_to(missouri,phelps_county).
related_to(missouri,carthage).
related_to(missouri,hooker).
related_to(missouri,concord).
related_to(missouri,holden).
related_to(missouri,elmer).
related_to(missouri,rosebud).
related_to(missouri,great_lakes).
related_to(missouri,salem).
related_to(missouri,putnam_county).
related_to(missouri,fulton).
related_to(missouri,miller_county).
related_to(missouri,iron_mountain).
related_to(missouri,newton_county).
related_to(missouri,savannah).
related_to(missouri,tracy).
related_to(missouri,ste_genevieve).
related_to(missouri,helton).
related_to(missouri,charleston).
related_to(missouri,jennings).
related_to(missouri,howell_county).
related_to(missouri,alton).
related_to(missouri,adair_county).
related_to(missouri,bourbon).
related_to(missouri,howard_county).
related_to(missouri,dekalb_county).
related_to(missouri,blue_ridge).
related_to(missouri,martinsville).
related_to(missouri,miami).
related_to(missouri,nevada).
related_to(missouri,stone).
related_to(missouri,crystal_city).
related_to(missouri,spooklight).
related_to(missouri,sandy_hook).
related_to(missouri,montana).
related_to(missouri,camdenton).
related_to(missouri,nodaway).
related_to(missouri,hillsboro).
related_to(missouri,lowndes).
related_to(missouri,tuscumbia).
related_to(missouri,elkton).
related_to(missouri,eolia).
related_to(missouri,shelbyville).
related_to(missouri,bowling_green).
related_to(missouri,rockbridge).
related_to(missouri,bollinger_county).
related_to(missouri,mercer).
related_to(missouri,ripley_county).
related_to(missouri,iron_county).
related_to(missouri,boonville).
related_to(missouri,ralls_county).
related_to(missouri,point_pleasant).
related_to(missouri,clinton).
related_to(missouri,ironton).
related_to(missouri,newtown).
related_to(missouri,houston).
related_to(missouri,rayville).
related_to(missouri,odessa).
related_to(missouri,hampton).
related_to(missouri,centralia).
related_to(missouri,scott_city).
related_to(missouri,avondale).
related_to(missouri,keytesville).
related_to(missouri,gerald).
related_to(missouri,bend).
related_to(missouri,augusta).
related_to(missouri,shaw).
related_to(missouri,hillsdale).
related_to(missouri,wilton).
related_to(missouri,fayette).
related_to(missouri,crook).
related_to(missouri,caldwell_county).
related_to(missouri,franklin).
related_to(missouri,osage).
related_to(missouri,aurora).
related_to(missouri,kerrville).
related_to(missouri,maries_county).
related_to(missouri,cassville).
related_to(missouri,purcell).
related_to(missouri,sedalia).
related_to(missouri,granger).
related_to(missouri,maryville).
related_to(missouri,rensselaer).
related_to(missouri,tilden).
related_to(missouri,novelty).
related_to(missouri,pembina).
related_to(missouri,des_arc).
related_to(missouri,dent_county).
related_to(missouri,baring).
related_to(missouri,kirksville).
related_to(missouri,collins).
related_to(missouri,napoleon).
related_to(missouri,mississippi_county).
related_to(missouri,crawford_county).
related_to(missouri,marble_hill).
related_to(missouri,union).
related_to(missouri,united_states).
related_to(missouri,oregon_county).
related_to(missouri,native_american).
related_to(missouri,forest_city).
related_to(missouri,christian_county).
related_to(missouri,perry).
related_to(missouri,greenville).
related_to(missouri,new_boston).
related_to(missouri,st_louis).
related_to(missouri,la_plata).
related_to(missouri,puke).
related_to(missouri,qulin).
related_to(missouri,holly_hills).
related_to(missouri,pulaski_county).
related_to(missouri,benton_county).
related_to(missouri,lewistown).
related_to(missouri,wayne_county).
related_to(missouri,camden_county).
related_to(missouri,youngstown).
related_to(missouri,morgan_county).
related_to(missouri,coldwater).
related_to(missouri,exeter).
related_to(missouri,hickory_county).
related_to(missouri,westport).
related_to(missouri,mendon).
related_to(missouri,osage_county).
related_to(missouri,liberal).
related_to(missouri,centerville).
related_to(missouri,harrisburg).
related_to(missouri,territory).
related_to(missouri,wheeling).
related_to(missouri,kansas_city).
related_to(missouri,anaconda).
related_to(missouri,dade_county).
related_to(missouri,rushville).
related_to(missouri,flemington).
related_to(missouri,cape_girardeau).
related_to(missouri,neosho).
related_to(missouri,ionia).
related_to(missouri,vienna).
related_to(missouri,rives).
related_to(missouri,vernon_county).
related_to(missouri,slater).
related_to(missouri,lincoln_county).
related_to(missouri,hollister).
related_to(missouri,valley_city).
related_to(missouri,jackson).
related_to(missouri,saline_county).
related_to(missouri,yolo).
related_to(missouri,gainesville).
related_to(missouri,new_madrid).
related_to(missouri,chariton_county).
related_to(missouri,jackson_county).
related_to(missouri,chillicothe).
related_to(missouri,clark_county).
related_to(missouri,lusk).
related_to(missouri,saint_louis).
related_to(missouri,atlanta).
related_to(missouri,taos).
related_to(missouri,henley).
related_to(missouri,mercer_county).
related_to(missouri,galt).
related_to(missouri,shrewsbury).
related_to(missouri,ashland).
related_to(missouri,kern).
related_to(missouri,st_john).
related_to(missouri,bates_county).
related_to(missouri,meta).
related_to(missouri,strasburg).
related_to(missouri,diggins).
related_to(missouri,oskaloosa).
related_to(missouri,eminence).
related_to(missouri,madisonville).
related_to(missouri,carroll_county).
related_to(missouri,ellisville).
related_to(missouri,knoxville).
related_to(missouri,jayhawker).
related_to(missouri,strafford).
related_to(missouri,liberty).
related_to(missouri,braymer).
related_to(missouri,warren_county).
related_to(missouri,gentry_county).
related_to(missouri,lamar).
related_to(missouri,tyrone).
related_to(missouri,monroe_county).
related_to(missouri,leesville).
related_to(missouri,americus).
related_to(missouri,gateway_city).
related_to(missouri,perry_county).
related_to(missouri,dallas_county).
related_to(missouri,st_george).
related_to(missouri,randolph).
related_to(missouri,st_francois_county).
related_to(missouri,mcdonald_county).
related_to(missouri,willard).
related_to(missouri,johnson_county).
related_to(missouri,new_london).
related_to(missouri,hayti).
related_to(missouri,albany).
related_to(missouri,huntington).
related_to(missouri,rockville).
related_to(missouri,urbana).
related_to(missouri,greene_county).
related_to(missouri,rockford).
related_to(missouri,corning).
related_to(missouri,bloomington).
related_to(missouri,mississippi).
related_to(missouri,jefferson_city).
related_to(missouri,iberia).
related_to(missouri,lawrence_county).
related_to(missouri,calhoun).
related_to(missouri,trenton).
related_to(missouri,jasper_county).
related_to(missouri,palo_pinto).
related_to(missouri,andrew_county).
related_to(missouri,dunklin_county).
related_to(missouri,clay_county).
related_to(missouri,cowgill).
related_to(missouri,independence).
related_to(missouri,schuyler_county).
related_to(missouri,goodland).
related_to(missouri,verona).
related_to(missouri,warrenton).
related_to(missouri,pocahontas).
related_to(missouri,mount_vernon).
related_to(missouri,minden).
related_to(missouri,buffalo).
related_to(missouri,grant_city).
related_to(missouri,polk_county).
related_to(missouri,st_francisville).
related_to(missouri,cooper_county).
related_to(missouri,republic).
related_to(missouri,fleming).
related_to(missouri,cosby).
related_to(missouri,delta).
related_to(missouri,nelson).
related_to(missouri,marion_county).
related_to(missouri,van_buren).
related_to(missouri,thomasville).
related_to(missouri,saginaw).
related_to(missouri,crane).
related_to(missouri,galesburg).
related_to(missouri,st_clair_county).
related_to(missouri,ozark).
related_to(missouri,osceola).
related_to(missouri,billings).
related_to(missouri,clarksville).
related_to(missouri,lafayette_county).
related_to(missouri,la_grange).
related_to(missouri,boone_county).
related_to(missouri,waynesville).
related_to(missouri,glencoe).
related_to(missouri,big_muddy).
related_to(missouri,clarksdale).
related_to(missouri,raymondville).
related_to(missouri,enterprise).
related_to(missouri,linn_county).
related_to(missouri,ray_county).
related_to(missouri,st_james).
related_to(missouri,dunlap).
related_to(missouri,butler_county).
related_to(missouri,raymore).
related_to(missouri,kingsville).
related_to(missouri,galena).
related_to(missouri,lynchburg).
related_to(missouri,clever).
related_to(missouri,chilton).
related_to(missouri,altenburg).
related_to(missouri,clinton_county).
related_to(missouri,madison).
related_to(missouri,warsaw).
related_to(missouri,stella).
related_to(missouri,worth_county).
related_to(missouri,racine).
related_to(missouri,walker).
related_to(missouri,stone_county).
related_to(missouri,cedar_county).
related_to(missouri,missourian).
related_to(missouri,marshall).
related_to(missouri,luray).
related_to(missouri,sulphur_springs).
related_to(missouri,bland).
related_to(missouri,cole_county).
related_to(missouri,sheldon).
related_to(missouri,jefferson_county).
related_to(missouri,lawrenceburg).
related_to(missouri,rankin).
related_to(missouri,essex).
related_to(missouri,forsyth).
related_to(missouri,katie).
related_to(missouri,gibbs).
related_to(missouri,center).
related_to(missouri,elmo).
related_to(missouri,roanoke).
related_to(missouri,mount_pleasant).
related_to(missouri,harrison_county).
related_to(missouri,milan).
related_to(missouri,yarrow).
related_to(missouri,de_kalb).
related_to(missouri,platte_county).
related_to(missouri,waverly).
related_to(missouri,macomb).
related_to(missouri,pendleton).
related_to(missouri,buchanan_county).
related_to(missouri,olney).
related_to(missouri,batesville).
related_to(missouri,howell).
related_to(missouri,benton).
related_to(missouri,akron).
related_to(missouri,ridgely).
related_to(missouri,cape_girardeau_county).
related_to(missouri,hamilton).
related_to(missouri,montrose).
related_to(missouri,woodville).
related_to(missouri,junction_city).
related_to(missouri,wright_county).
related_to(missouri,sullivan_county).
related_to(missouri,lexington).
related_to(missouri,amazonia).
related_to(missouri,reynolds_county).
related_to(missouri,greeley).
related_to(missouri,cass_county).
related_to(missouri,atchison_county).
related_to(missouri,big_lake).
related_to(missouri,astoria).
related_to(missouri,belton).
related_to(missouri,butts).
related_to(missouri,millersburg).
related_to(missouri,webster_county).
related_to(missouri,jasper).
related_to(missouri,barton_county).
related_to(missouri,livingston_county).
related_to(missouri,clearwater).
related_to(missouri,st_charles).
related_to(missouri,phillipsburg).
related_to(missouri,great_bend).
related_to(missouri,tightwad).
related_to(missouri,greenwood).
related_to(missouri,cuba).
related_to(missouri,steele).
related_to(missouri,washington_county).
related_to(missouri,danville).
related_to(missouri,ripley).
related_to(missouri,lewis_county).
related_to(missouri,foster).
related_to(missouri,moniteau_county).
related_to(missouri,downing).
related_to(missouri,edgerton).
related_to(missouri,lithium).
related_to(missouri,carter_county).
related_to(missouri,st_louis_county).
related_to(missouri,pike_county).
related_to(missouri,madison_county).
related_to(missouri,pettis_county).
related_to(missouri,caledonia).
related_to(missouri,huron).
related_to(missouri,evergreen).
related_to(missouri,tallapoosa).
related_to(missouri,audrain_county).
related_to(missouri,farmington).
related_to(missouri,creighton).
related_to(missouri,paris).
related_to(missouri,linn).
related_to(missouri,dawsonville).
related_to(missouri,tiffin).
related_to(missouri,arcadia).
related_to(missouri,princeton).
related_to(missouri,shelbina).
related_to(missouri,lupus).
related_to(missouri,white_cloud).
related_to(missouri,defiance).
related_to(missouri,mckittrick).
related_to(missouri,chariton).
related_to(missouri,sweetwater).
related_to(missouri,summersville).
related_to(missouri,gasconade).
related_to(missouri,bosworth).
related_to(missouri,bellflower).
related_to(missouri,platte_city).
related_to(missouri,barry_county).
related_to(missouri,goshen).
related_to(missouri,laclede).
related_to(missouri,clayton).
related_to(missouri,fisk).
related_to(missouri,bigelow).
related_to(missouri,tribe).
related_to(missouri,altamont).
related_to(missouri,greene_springs).
related_to(missouri,anniston).
related_to(missouri,st_joseph).
related_to(missouri,caruthersville).
related_to(missouri,butler).
related_to(missouri,callaway_county).
related_to(missouri,catlinite).
related_to(missouri,martinsburg).
related_to(missouri,pineville).
related_to(missouri,golden).
related_to(missouri,macon).
related_to(missouri,gladstone).
related_to(missouri,pemiscot_county).
related_to(missouri,troy).
related_to(missouri,perryville).
related_to(missouri,shelby_county).
related_to(missouri,silverton).
related_to(missouri,garden_city).
related_to(missouri,scotland_county).
related_to(missouri,henry_county).
related_to(missouri,doniphan).
related_to(missouri,taney_county).
related_to(missouri,julesburg).
related_to(missouri,wheatland).
related_to(missouri,little_river).
related_to(missouri,randolph_county).
related_to(missouri,theodosia).
related_to(missouri,macon_county).
related_to(missouri,montgomery_county).
related_to(missouri,mexico).
related_to(missouri,texas_county).
related_to(missouri,stoddard_county).
related_to(missouri,kingston).
related_to(missouri,new_madrid_county).
related_to(missouri,ozark_county).
related_to(missouri,richmond).
related_to(missouri,st_paul_sandwich).
related_to(missouri,ste_genevieve_county).
related_to(missouri,hermann).
related_to(missouri,norwood).
related_to(missouri,coffey).
related_to(missouri,carrollton).
related_to(missouri,greenfield).
related_to(missouri,palmyra).
related_to(missouri,monticello).
related_to(missouri,morrison).
related_to(missouri,eureka).
related_to(missouri,stockton).
related_to(missouri,johnson_city).
related_to(missouri,sumner).
related_to(missouri,passaic).
related_to(missouri,easley).
related_to(missouri,lancaster).
related_to(missouri,bushnell).
related_to(missouri,rea).
related_to(missouri,pawnee).
related_to(missouri,memphis).
related_to(missouri,glasgow).
related_to(missouri,edinburg).
related_to(missouri,bridgeport).
related_to(missouri,scott_county).
related_to(missouri,graham).
related_to(missouri,winona).
related_to(missouri,oregon).
related_to(missouri,waco).
related_to(missouri,breckenridge).
related_to(missouri,hermitage).
related_to(missouri,darlington).
related_to(missouri,sylvania).
related_to(missouri,hannibal).
related_to(missouri,paw_paw).
related_to(missouri,richland).
related_to(missouri,hartville).
related_to(missouri,mott).
related_to(missouri,rogersville).
related_to(missouri,douglas_county).
related_to(missouri,laclede_county).
related_to(missouri,barnesville).
related_to(missouri,university).
related_to(missouri,river).
contains(example_98,town).
related_to(town,city).
related_to(town,village).
related_to(town,street).
related_to(town,main_street).
related_to(town,jurat).
related_to(town,hyde).
related_to(town,dodona).
related_to(town,bushey).
related_to(town,sandy).
related_to(town,panstereorama).
related_to(town,townswoman).
related_to(town,tusayan).
related_to(town,townlike).
related_to(town,kotwal).
related_to(town,circuit_rider).
related_to(town,townwide).
related_to(town,vratsa).
related_to(town,kurnool).
related_to(town,ainsworth).
related_to(town,ribadesella).
related_to(town,lermontov).
related_to(town,rochdale).
related_to(town,clun).
related_to(town,anantapur).
related_to(town,san_carlos).
related_to(town,helston).
related_to(town,nantou).
related_to(town,north_shields).
related_to(town,square).
related_to(town,pazardzhik).
related_to(town,tirzah).
related_to(town,earley).
related_to(town,boko).
related_to(town,evacuation).
related_to(town,bootle).
related_to(town,population).
related_to(town,out_of_towner).
related_to(town,townwards).
related_to(town,monotown).
related_to(town,alor_gajah).
related_to(town,valdastico).
related_to(town,township).
related_to(town,toon).
related_to(town,shrewsbury).
related_to(town,bytown).
related_to(town,cherokee).
related_to(town,shumen).
related_to(town,dumfries).
related_to(town,lamu).
related_to(town,banstead).
related_to(town,townpeople).
related_to(town,rye).
related_to(town,sliven).
related_to(town,caledon).
related_to(town,terminus).
related_to(town,frome).
related_to(town,ilmajoki).
related_to(town,aytos).
related_to(town,bajina_bašta).
related_to(town,kuhmo).
related_to(town,drunksville).
related_to(town,burg).
related_to(town,university).
related_to(town,town_square).
related_to(town,kidderminster).
related_to(town,townsmate).
related_to(town,weston_super_mare).
related_to(town,pettah).
related_to(town,heinola).
related_to(town,gabrovo).
related_to(town,nerdistan).
related_to(town,naubinway).
related_to(town,intown).
related_to(town,leesburg).
related_to(town,jesolo).
related_to(town,mauldin).
related_to(town,llanelli).
related_to(town,lyme_regis).
related_to(town,barry).
related_to(town,mesudiye).
related_to(town,sexville).
related_to(town,fleet).
related_to(town,gateshead).
related_to(town,manarola).
related_to(town,queensferry).
related_to(town,usk).
related_to(town,caernarfon).
related_to(town,gushan).
related_to(town,amenia).
related_to(town,carfax).
related_to(town,night_watch).
related_to(town,medvedgrad).
related_to(town,bury).
related_to(town,michurin).
related_to(town,bala).
related_to(town,silicon_beach).
related_to(town,orimattila).
related_to(town,oldham).
related_to(town,twinning).
related_to(town,buckingham).
related_to(town,nellore).
related_to(town,wandoan).
related_to(town,lavarone).
related_to(town,battle).
related_to(town,townscaper).
related_to(town,barnsley).
related_to(town,loftus).
related_to(town,pella).
related_to(town,tabo).
related_to(town,dorpie).
related_to(town,kadapa).
related_to(town,orange).
related_to(town,gillingham).
related_to(town,christchurch).
related_to(town,west_kirby).
related_to(town,lieksa).
related_to(town,honea_path).
related_to(town,high_street).
related_to(town,castletown).
related_to(town,albi).
related_to(town,deal).
related_to(town,b_road).
related_to(town,abbeville).
related_to(town,marlow).
related_to(town,galich).
related_to(town,aberystwyth).
related_to(town,lyttelton).
related_to(town,townward).
related_to(town,intercourse).
related_to(town,mudeford).
related_to(town,ville).
related_to(town,waterloo).
related_to(town,yukon).
related_to(town,bideford).
related_to(town,metropolitan_area).
related_to(town,county_borough).
related_to(town,teignmouth).
related_to(town,nanshan).
related_to(town,botevgrad).
related_to(town,kajaani).
related_to(town,putney).
related_to(town,shtetl).
related_to(town,old_town).
related_to(town,llandeilo).
related_to(town,hadleigh).
related_to(town,tarvisio).
related_to(town,birthtown).
related_to(town,gown).
related_to(town,burton_upon_trent).
related_to(town,ascoli_piceno).
related_to(town,carmen).
related_to(town,maidenhead).
related_to(town,delphia).
related_to(town,greenwich).
related_to(town,cardboard_city).
related_to(town,sastamala).
related_to(town,towns).
related_to(town,upton).
related_to(town,hamina).
related_to(town,khammam).
related_to(town,zhapu).
related_to(town,jasin).
related_to(town,urban).
related_to(town,parkano).
related_to(town,varkaus).
related_to(town,cheltenham).
related_to(town,outparish).
related_to(town,veliko_tărnovo).
related_to(town,stockport).
related_to(town,selectman).
related_to(town,friend_of_ours).
related_to(town,whitby).
related_to(town,cobalt).
related_to(town,rural_sanitary_district).
related_to(town,milton_keynes).
related_to(town,tornio).
related_to(town,cheshunt).
related_to(town,medicine_hat).
related_to(town,lapua).
related_to(town,outokumpu).
related_to(town,walsall).
related_to(town,urbanization).
related_to(town,woolwich).
related_to(town,weymouth).
related_to(town,pelzer).
related_to(town,outharbour).
related_to(town,corregidor).
related_to(town,hell).
related_to(town,townlet).
related_to(town,urbana).
related_to(town,neman).
related_to(town,quarter).
related_to(town,casern).
related_to(town,dingxian).
related_to(town,freeman).
related_to(town,wolverton).
related_to(town,municipium).
related_to(town,glocester).
related_to(town,bromley).
related_to(town,burnham).
related_to(town,kurikka).
related_to(town,foreign).
related_to(town,seafront).
related_to(town,marlborough).
related_to(town,dayton).
related_to(town,alderman).
related_to(town,weybridge).
related_to(town,andover).
related_to(town,hingham).
related_to(town,townsite).
related_to(town,china).

related_to(town,ton).
related_to(town,imatra).
related_to(town,oswestry).
related_to(town,winchcombe).
related_to(town,kristinestad).
related_to(town,staines).
related_to(town,sukhothai).
related_to(town,portishead).
related_to(town,vis).
related_to(town,sciara).
related_to(town,ilford).
related_to(town,market_square).
related_to(town,bumbunga).
related_to(town,resident).
related_to(town,lydd).
related_to(town,jarrow).
related_to(town,ostia).
related_to(town,archite).
related_to(town,by).
related_to(town,akaa).
related_to(town,cato).
related_to(town,worthing).
related_to(town,razgrad).
related_to(town,gressoney_saint_jean).
related_to(town,palookaville).
related_to(town,silistra).
related_to(town,port_erin).
related_to(town,azov).
related_to(town,staple).
related_to(town,residential).
related_to(town,suburban).
related_to(town,srikakulam).
related_to(town,featherstone).
related_to(town,seaport).
related_to(town,cramlington).
related_to(town,ghost_town).
related_to(town,bastide).
related_to(town,maine).
related_to(town,main_road).
related_to(town,kaskinen).
related_to(town,multitown).
related_to(town,paarl).
related_to(town,barrow).
related_to(town,medak).
related_to(town,afula).
related_to(town,conwy).
related_to(town,brunswick).
related_to(town,abington).
related_to(town,whitehaven).
related_to(town,newquay).
related_to(town,market).
related_to(town,seaton).
related_to(town,choctaw_corner).
related_to(town,townhood).
related_to(town,whitman).
related_to(town,disincorporate).
related_to(town,waterworks).
related_to(town,lom).
related_to(town,paignton).
related_to(town,kazanlăk).
related_to(town,valkeakoski).
related_to(town,draper).
related_to(town,hartlepool).
related_to(town,megalopoli).
related_to(town,outskirts).
related_to(town,bump_in_road).
related_to(town,riwon).
related_to(town,shop).
related_to(town,krk).
related_to(town,precinct).
related_to(town,marketplace).
related_to(town,karimnagar).
related_to(town,urbanologist).
related_to(town,susedgrad).
related_to(town,sardinia).
related_to(town,tuzi).
related_to(town,pace).
related_to(town,settlement).

related_to(town,corby).
related_to(town,dorp).
related_to(town,formby).
related_to(town,barbican).
related_to(town,hackney).
related_to(town,lenox).
related_to(town,bayburt).
related_to(town,overworld).
related_to(town,iwon).
related_to(town,ogre).
related_to(town,dunbar).
related_to(town,iva).
related_to(town,fire_alarm_horn).
related_to(town,hog_wallowing).
related_to(town,intertown).
related_to(town,yandang).
related_to(town,consul).
related_to(town,peel).
related_to(town,fringe).
related_to(town,leatherhead).
related_to(town,halifax).
related_to(town,verulam).
related_to(town,satellite_town).
related_to(town,kauhajoki).
related_to(town,tiberias).
related_to(town,cherrapunji).
related_to(town,shitsville).
related_to(town,pernik).
related_to(town,yeovil).
related_to(town,emmaus).
related_to(town,nurmes).
related_to(town,setouchi).
related_to(town,earby).
related_to(town,marsala).
related_to(town,montana).
related_to(town,outport).
related_to(town,townsfolk).
related_to(town,burlington).
related_to(town,wrexham).
related_to(town,nahiyah).
related_to(town,ramsey).
related_to(town,raahe).
related_to(town,torquay).
related_to(town,khaskovo).
related_to(town,schaghticoke).
related_to(town,atherton).
related_to(town,townsman).
related_to(town,montseny).
related_to(town,halstead).
related_to(town,roadhouse).
related_to(town,brandenburg).
related_to(town,municipal_borough).
related_to(town,bobbili).
related_to(town,ubud).
related_to(town,scunthorpe).
related_to(town,tulbagh).
related_to(town,town_council).
related_to(town,carnforth).
related_to(town,alton).
related_to(town,vidin).
related_to(town,small_town).
related_to(town,regional).
related_to(town,flora).
related_to(town,swansea).
related_to(town,marple).
related_to(town,ramsgate).
related_to(town,clarksville).
related_to(town,brighton).
related_to(town,woking).
related_to(town,waterfront).
related_to(town,kirkham).
related_to(town,rupert).
related_to(town,podesta).
related_to(town,outskirt).
related_to(town,lappeenranta).
related_to(town,cahors).
related_to(town,lovech).
related_to(town,bognor_regis).
related_to(town,student_ghetto).
related_to(town,blagoevgrad).
related_to(town,kerobokan).
related_to(town,ayden).
