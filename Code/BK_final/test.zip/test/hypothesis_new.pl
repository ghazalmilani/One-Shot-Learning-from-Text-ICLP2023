category_1(A,environment):-related_to(A,environment),!.
category_1(A,B):-related_to(A,C),category_1(C,B).
category(A,B):-contains(A,C),category_1(C,B).